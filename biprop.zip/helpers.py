from typing import Callable, Literal, overload, Mapping
from simulation import SimRecord
from tanks import SourceRole, TankConfig
from regulator import RegulatorConfig, PropellantRole
from injector import InjectorConfig


def bisection_search(
        residual_func: Callable, 
        bounds: list, 
        max_iterations: int = 100,
        tolerance: float = 1e-3
        ) -> float:

    low = bounds[0]
    high = bounds[1]

    low_residual = residual_func(low)
    high_residual = residual_func(high)

    if low_residual * high_residual > 0.0:
        raise ValueError(
            f"Bisection bounds do not bracket a root: "
            f"f({low})={low_residual}, f({high})={high_residual}"
        )

    iteration = 0

    while iteration < max_iterations:
        
        mid = 0.5 * (low + high)

        mid_residual = residual_func(mid)
        
        # stop once residual is close enough to zero
        if abs(mid_residual) < tolerance:
            break

        # keep the half-interval that still has the sign change
        if low_residual * mid_residual <= 0.0:
            high = mid
            high_residual = mid_residual
        else:
            low = mid
            low_residual = mid_residual
        
        iteration +=1

        if iteration > 100:
            raise RuntimeError(f"Root search failed to converge after 100 iterations. Final residual of {mid_residual}")

    return 0.5 * (low + high)



def log_results(file_path:str, sim_record: SimRecord):
    """
    saves the simulation results to a csv file for later analysis, with data rounded to 2 decimal places for readability.
    Works dynamically with any number/name of tanks, injectors, and regulators.
    """
    with open(file_path, 'w') as f:
        # Build header dynamically based on available data
        headers = ["time_s"]
        
        # Add tank headers
        if sim_record.points and sim_record.points[0].tanks is not None:
            for tank_name in sim_record.points[0].tanks.keys():
                headers.extend([
                    f"{tank_name}_pressure_bar",
                    f"{tank_name}_temperature_k",
                    f"{tank_name}_liquid_mass_kg",
                    f"{tank_name}_vapour_mass_kg",
                    f"{tank_name}_pressurant_gas_mass_kg",
                    f"{tank_name}_total_mass_kg",
                    f"{tank_name}_total_internal_energy_j"
                ])
        
        # Add injector headers
        if sim_record.points and sim_record.points[0].injectors_mdot is not None:
            for injector_name in sim_record.points[0].injectors_mdot.keys():
                headers.append(f"{injector_name}_mdot_kg_s")
        
        f.write(",".join(headers) + "\n")
        
        # Write data rows
        for point in sim_record.points:
            row_data = [f"{point.time_s:.2f}"]
            
            # Extract tank data
            if point.tanks is not None:
                for tank_name, tank in point.tanks.items():
                    # Safely format values, writing empty string for None
                    row_data.extend([
                        f"{tank.pressure_pa/1e5:.2f}" if tank.pressure_pa is not None else "",
                        f"{tank.temperature_k:.2f}" if tank.temperature_k is not None else "",
                        f"{tank.liquid_mass_kg:.2f}" if tank.liquid_mass_kg is not None else "",
                        f"{tank.vapour_mass_kg:.2f}" if tank.vapour_mass_kg is not None else "",
                        f"{tank.pressurant_gas_mass_kg:.2f}" if tank.pressurant_gas_mass_kg is not None else "",
                        f"{tank.total_mass_kg:.2f}" if tank.total_mass_kg is not None else "",
                        f"{tank.total_internal_energy_j:.2f}" if tank.total_internal_energy_j is not None else ""
                    ])
            
            # Extract injector data
            if point.injectors_mdot is not None:
                for injector_name, mdot in point.injectors_mdot.items():
                    row_data.append(f"{mdot:.2f}")
            
            f.write(",".join(row_data) + "\n")





ConfigTypes = Literal["tank", "injector", "regulator"]


@overload
def get_single_config_by_role(
    configs: Mapping[str, TankConfig],
    role: SourceRole,
    config_type_name: Literal["tank"],
) -> tuple[str, TankConfig]:
    ...

@overload
def get_single_config_by_role(
    configs: Mapping[str, InjectorConfig],
    role: PropellantRole,
    config_type_name: Literal["injector"],
) -> tuple[str, InjectorConfig]:
    ...


@overload
def get_single_config_by_role(
    configs: Mapping[str, RegulatorConfig],
    role: PropellantRole,
    config_type_name: Literal["regulator"],
) -> tuple[str, RegulatorConfig]:
    ...


def get_single_config_by_role(
    configs: (
        Mapping[str, TankConfig]
        | Mapping[str, InjectorConfig]
        | Mapping[str, RegulatorConfig]
    ),
    role: SourceRole,
    config_type_name: ConfigTypes,
) -> tuple[str, TankConfig | InjectorConfig | RegulatorConfig]:
    """
    Finds one config object with the specified role.

    Used when a sim requires a single component for a given role, such as one fuel tank, one oxidiser tank, or one fuel injector. Searches through a dictionary of config objects and returns matching dictionary key and congig object.
    """
    
    if (config_type_name == "injector" or config_type_name == "regulator") and role == "pressurant":
        raise ValueError(f"{config_type_name} config cannot have role 'pressurant'.")

    matching_items = [
        (config_id, config)
        for config_id, config in configs.items()
        if config.role == role
    ]

    if len(matching_items) == 0:
        raise ValueError(f"No {config_type_name} config found with role '{role}'.")

    if len(matching_items) > 1:
        matching_ids = [config_id for config_id, _ in matching_items]
        raise ValueError(
            f"Multiple {config_type_name}configs found with role '{role}': "
            f"{matching_ids}"
        )

    return matching_items[0]